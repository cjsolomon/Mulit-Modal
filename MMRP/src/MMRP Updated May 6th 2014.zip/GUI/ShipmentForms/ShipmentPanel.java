package GUI.ShipmentForms;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;

import core.Shipment;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ShipmentPanel extends JPanel {
	
	ShipmentTable st;
	ShipmentForm sf;
	JScrollPane sp,sp2;
	JTabbedPane jp;
	ShipmentHistoryTable sht;
	private JButton btnDelete;
	private JButton btnNew;
	private JButton btnView;
	
	public ShipmentPanel(final GUI.Main_Source main)
	{
		setLayout(new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("max(64dlu;default)"),
				ColumnSpec.decode("max(117dlu;default)"),
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("max(12dlu;default)"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				ColumnSpec.decode("max(71dlu;default)"),},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				RowSpec.decode("max(84dlu;default)"),
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,}));
		
		st=new ShipmentTable(main);
		sf = new ShipmentForm(main);
		jp = new JTabbedPane();
		sht = new ShipmentHistoryTable(main);
		sht.setVisible(false);
		jp.setVisible(false);
		
		//sf.setBorder(new MatteBorder(0, 0, 0, 2, (Color) new Color(0, 0, 0)));
		sf.setVisible(false);
		st.setVisible(false);
		sp = new JScrollPane();
		sp.setViewportView(st);
		sp.setVisible(false);
		sp2 = new JScrollPane();
		sp2.setViewportView(sht);
		sp2.setVisible(false);
		jp.addTab("Info", sf);
		jp.addTab("History",sp2);
		
		jp.getModel().addChangeListener(new ChangeListener(){
			public void stateChanged(ChangeEvent e)
			{
				if(jp.getSelectedIndex()==0)
				{
					sf.setVisible(true);
					sp2.setVisible(false);
				}
				else
				{
					sf.setVisible(false);
					sp2.setVisible(true);
				}
			}
		});
		add(sp, "2, 2, 8, 5");
		
		st.getSelectionModel().addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e)
			{
				if(st.getSelectedRow()!=-1)
				{
					jp.setVisible(true);
					sp2.setVisible(true);
					//sht.showPanel(st.getSelectedShipment());
					
					sht.showPanel(st.getSelectedShipment());
					sf.showPanel(st.getSelectedShipment());
					sp2.setVisible(false);
					jp.setSelectedComponent(sf);
				}
			}
		});
		btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(st.getSelectedRow()!=-1)
				{
					jp.setVisible(true);
					sp2.setVisible(true);
					//sht.showPanel(st.getSelectedShipment());
					sf.showPanel(st.getSelectedShipment());
					sht.showPanel(st.getSelectedShipment());
					jp.setSelectedIndex(0);
				}
			}
		});
	//	add(btnView, "7, 7");
		
		btnNew = new JButton("New");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				jp.setVisible(true);
				sp2.setVisible(true);
				sht.showPanel(null);
				sf.showPanel();
				jp.setSelectedIndex(0);
			}
		});
		add(btnNew, "8, 7");
		
		btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(st.getSelectedRow()!=-1)
				{
					st.getSelectedShipment().Delete();
					st.refresh();
				}
			}
		});
		add(btnDelete, "9, 7");
		add(jp,"2, 8, 8, 1");
		
	}
	public void showPanel(int id, final GUI.Main_Source main)
	{
		
		if(id == 0){
			sp.setVisible(true);
			st.showPanel();
			sf.setVisible(false);
			setVisible(true);
			main.setShipment(0);
		}else{
			//btnView.doClick();
			Shipment shipment = Shipment.Load(id);
			jp.setVisible(true);
			sp2.setVisible(true);
			st.showPanel();
			//sht.showPanel(st.getSelectedShipment());
			sf.showPanel(shipment);
			sht.showPanel(shipment);
			jp.setSelectedIndex(0);
			sp.setVisible(true);
			setVisible(true);
			main.setShipment(0);
		}
	}

}
