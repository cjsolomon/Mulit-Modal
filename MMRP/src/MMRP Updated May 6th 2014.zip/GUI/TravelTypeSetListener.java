package GUI;

public interface TravelTypeSetListener {
	public void setTravelType();
	
}
