package ChrisGUILogic;

interface TableRefreshListener {
	public void refreshTable();

}
